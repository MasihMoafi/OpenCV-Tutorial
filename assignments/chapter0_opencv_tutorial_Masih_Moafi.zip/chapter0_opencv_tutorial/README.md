# تکلیف فصل صفرم - آموزش OpenCV
## یادگیری محیط برنامه‌نویسی OpenCV

**دانشجو:** مسیح معافی  
**استاد:** دکتر محمد داورپناه جزی  
**درس:** بینایی کامپیوتر  
**ترم:** اول 1404-1405

---

## 📋 شرح تکلیف

یادگیری محیط برنامه‌نویسی OpenCV با توجه به بیان مثال‌های مرتبط با هر یک از موضوعات درس بر مبنای امکانات این محیط و همچنین لزوم انجام تعدادی از تکالیف درس به‌صورت پیاده‌سازی در این محیط.

این کار به‌عنوان یک کار اضافی برای درس در نظر گرفته می‌شود.

### 🎓 دوره‌های رایگان OpenCV

OpenCV دوره‌های رایگان متعددی در وب‌سایت رسمی خود ارائه می‌دهد:
- **لینک:** https://courses.opencv.org/courses/
- **محتوا:** دوره‌های ساختاریافته از مبتدی تا پیشرفته
- **زبان:** انگلیسی
- **هزینه:** رایگان

### 📦 روش‌های نصب

بسته به سیستم‌عامل و مدیر بسته، روش‌های مختلفی برای نصب OpenCV وجود دارد:

**با pip (توصیه می‌شود):**
```bash
pip install opencv-python
```

**با uv (سریع‌تر):**
```bash
uv pip install opencv-python
```

**با Anaconda:**
```bash
conda install -c conda-forge opencv
```

جزئیات بیشتر در `01_installation_guide.md`

---

## 📚 محتویات

### بخش اول: نصب و راه‌اندازی
- `01_installation_guide.md` - راهنمای نصب OpenCV
- `02_first_program.py` - اولین برنامه با OpenCV

### بخش دوم: مفاهیم پایه
- `03_reading_images.py` - خواندن و نمایش تصاویر
- `04_image_properties.py` - ویژگی‌های تصویر
- `05_color_spaces.py` - فضاهای رنگی

### بخش سوم: پردازش تصویر
- `06_image_operations.py` - عملیات روی تصاویر
- `07_filtering.py` - فیلترها و هموارسازی
- `08_edge_detection.py` - تشخیص لبه

### بخش چهارم: مثال‌های کاربردی
- `09_practical_examples.py` - مثال‌های عملی
- `opencv_complete_tutorial.ipynb` - نوت‌بوک جامع با تمام مثال‌ها و نتایج
- `results/` - تصاویر نتایج تولید شده

### منابع
- `resources.md` - لینک‌های مفید و منابع یادگیری

---

## 🎯 اهداف یادگیری

پس از مطالعه این مطالب، دانشجو قادر خواهد بود:

1. نصب و راه‌اندازی OpenCV در Python
2. خواندن، نمایش و ذخیره تصاویر
3. تبدیل بین فضاهای رنگی مختلف
4. اعمال فیلترها و عملیات پردازش تصویر
5. پیاده‌سازی الگوریتم‌های ساده بینایی کامپیوتر

---

## 🚀 نحوه استفاده

### ⚡ شروع سریع
برای شروع سریع، فایل `QUICK_START.md` را مطالعه کنید!

### روش اول: اجرای خودکار (توصیه می‌شود)
```bash
# Linux/Mac
./generate_outputs.sh

# Windows
generate_outputs.bat
```

### روش دوم: Jupyter Notebook
```bash
jupyter notebook opencv_complete_tutorial.ipynb
# سپس: Kernel → Restart & Run All
```

### روش سوم: مشاهده نتایج آماده
- فایل HTML: `opencv_complete_tutorial.html`
- فایل PDF: `opencv_complete_tutorial.pdf`
- پوشه نتایج: `results/`

### روش چهارم: اجرای دستی
```bash
python 02_first_program.py
```

---

## 📖 منابع مورد استفاده

1. **OpenCV Official Documentation**
   - https://docs.opencv.org/4.x/

2. **OpenCV Python Tutorials**
   - https://docs.opencv.org/4.x/d6/d00/tutorial_py_root.html

3. **کتاب درس:**
   - A Practical Introduction to Computer Vision with OpenCV
   - Dawson-Howe K., John Wiley & Sons Ltd.

4. **منابع آنلاین:**
   - Real Python OpenCV Tutorial
   - PyImageSearch Blog
   - LearnOpenCV.com

---

## ✅ وضعیت تکمیل

- [x] نصب و راه‌اندازی
- [x] مفاهیم پایه
- [x] پردازش تصویر
- [x] مثال‌های کاربردی
- [x] مستندسازی

---

**تاریخ تکمیل:** ۲۲ مهر ۱۴۰۴ (14 اکتبر 2025)
